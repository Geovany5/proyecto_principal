<?php
// Redirecciona a la página login/index.html
header("Location: login/index.html");
exit; // Asegúrate de terminar el script después de la redirección
?>
